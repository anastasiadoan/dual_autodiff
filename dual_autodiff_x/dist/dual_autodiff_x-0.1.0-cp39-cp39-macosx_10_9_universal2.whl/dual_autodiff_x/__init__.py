from .dual import Dual

